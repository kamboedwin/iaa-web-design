IIA WEB DESIGN — UNIT 1 HTML STARTER

1. Extract this folder.
2. Open index.html using Notepad, VS Code or another plain-text editor.
3. Replace the service name, introduction and list entries with a fictional
   library or records centre.
4. Add at least two more services and another helpful section.
5. Save the file with the .html extension.
6. Double-click index.html to open it in a web browser.
7. Keep the file and a screenshot for your assignment evidence.

You can use these files completely offline. No personal or confidential records
should be included.
