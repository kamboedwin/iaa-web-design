UNIT 10 — JAVASCRIPT BUTTON PRACTICAL

1. Open index.html in a web browser.
2. Select the service-information button.
3. Open script.js in a text editor.
4. Change the message and save the file.
5. Refresh the webpage and select the button again.

Use fictional service information only.
