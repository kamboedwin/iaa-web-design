// This script displays helpful public information when the button is clicked.
const button = document.getElementById("showInfo");
const message = document.getElementById("message");
button.addEventListener("click", function () {
  message.textContent = "Opening hours: Monday–Friday, 08:00–17:00. Please ask the circulation desk for assistance.";
});
