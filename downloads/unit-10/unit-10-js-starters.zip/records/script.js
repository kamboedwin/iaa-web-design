// This script displays helpful public information when the button is clicked.
const button = document.getElementById("showInfo");
const message = document.getElementById("message");
button.addEventListener("click", function () {
  message.textContent = "For general public enquiries, contact the information desk and review the published request procedure.";
});
