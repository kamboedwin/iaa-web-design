UNIT 4: ORGANISING WEB CONTENT

Choose either library-example or records-example. Open its index.html in a browser. Follow Services and Contact, then test the Home links. All information and addresses are fictional. Change the text to suit your exercise.
