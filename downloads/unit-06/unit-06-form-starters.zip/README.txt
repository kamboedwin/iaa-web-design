UNIT 6 — HTML FORMS
Open a sample HTML file in a browser, then edit it with a text editor. All details are fictional.
Submission processing and data storage are not included in these beginner examples.
