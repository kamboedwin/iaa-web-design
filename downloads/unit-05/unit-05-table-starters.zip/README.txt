Unit 5: HTML Tables

Open one of the HTML files in a text editor. Change the caption, add two fictional entries, save and open the file in a browser. Do not include real personal or confidential data.
